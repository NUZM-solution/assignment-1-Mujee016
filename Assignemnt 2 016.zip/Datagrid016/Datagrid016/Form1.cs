using System.Data;

namespace Datagrid016
{
    public partial class Form1 : Form
    {

        DataTable dt = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataColumn dc1 = new DataColumn("Course code", typeof(int));
            DataColumn dc2 = new DataColumn("Course title", typeof(string));
            DataColumn dc3 = new DataColumn("Obtained Marks", typeof(int));
            DataColumn dc4 = new DataColumn("Grade", typeof(string));
            DataColumn dc5 = new DataColumn("Status", typeof(string));
            dt.Columns.Add(dc1);
            dt.Columns.Add(dc2);
            dt.Columns.Add(dc3);
            dt.Columns.Add(dc4);
            dt.Columns.Add(dc5);
            //dataGridView1.DataSource = dt;
        }
        public void createnewrow()
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) ||
                string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text) ||
                cmb_type.SelectedItem == null)
            {
                MessageBox.Show("Please fill the field");
                return;
            }
            dt.Rows.Add(Convert.ToInt32(textBox1.Text), textBox2.Text, Convert.ToInt32(textBox3.Text),
                textBox4.Text, cmb_type.SelectedItem.ToString());
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            createnewrow();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void AddExitDeleteUpdateButtons()
        {
            // Create and position buttons (adjust positions as needed)
            Button btnExit = new Button();
            btnExit.Text = "Exit";
            btnExit.Location = new Point(300, 300);  // Adjust location
            btnExit.Click += new EventHandler(ExitButton_Click);
            Controls.Add(btnExit);

            Button btnDelete = new Button();
            btnDelete.Text = "Delete";
            btnDelete.Location = new Point(200, 300);  // Adjust location
            btnDelete.Click += new EventHandler(DeleteButton_Click);
            Controls.Add(btnDelete);

            // **Note:** Update button functionality for future implementation (commented out for now)
            // Button btnUpdate = new Button();
            // btnUpdate.Text = "Update";
            // btnUpdate.Location = new Point(100, 300);  // Adjust location
            // btnUpdate.Click += new EventHandler(UpdateButton_Click);
            // Controls.Add(btnUpdate);
        }
        private void ExitButton_Click(object sender, EventArgs e)
        {
            Close(); // Close the form
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            // Implement logic to delete selected row(s) from the DataTable

            // Check if any rows are selected
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to delete.");
                return;
            }

            // Get selected rows
            foreach (DataGridViewRow row in dataGridView1.SelectedRows)
            {
                dt.Rows.Remove(row.DataBoundItem as DataRow); // Remove selected row(s)
            }

            // Update the DataGridView to reflect the

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            // Check if there is a selected row to delete
            if (dataGridView1.SelectedRows.Count > 0)
            {
                dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

      

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

