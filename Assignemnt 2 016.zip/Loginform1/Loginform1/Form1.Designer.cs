﻿namespace Loginform1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txt_Username = new TextBox();
            txt_Password = new TextBox();
            btn_Login = new Button();
            btn_Reset = new Button();
            btn_Exit = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 14F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(226, 9);
            label1.Name = "label1";
            label1.Size = new Size(193, 21);
            label1.TabIndex = 0;
            label1.Text = "Welcome To Login page";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 10F);
            label2.ForeColor = Color.White;
            label2.Location = new Point(14, 57);
            label2.Name = "label2";
            label2.Size = new Size(63, 16);
            label2.TabIndex = 1;
            label2.Text = "Username";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 10F);
            label3.ForeColor = Color.White;
            label3.Location = new Point(14, 102);
            label3.Name = "label3";
            label3.Size = new Size(63, 16);
            label3.TabIndex = 2;
            label3.Text = "Password";
            // 
            // txt_Username
            // 
            txt_Username.Font = new Font("Times New Roman", 10F);
            txt_Username.Location = new Point(98, 54);
            txt_Username.Name = "txt_Username";
            txt_Username.Size = new Size(209, 23);
            txt_Username.TabIndex = 3;
            // 
            // txt_Password
            // 
            txt_Password.Font = new Font("Times New Roman", 10F);
            txt_Password.Location = new Point(98, 95);
            txt_Password.Name = "txt_Password";
            txt_Password.PasswordChar = '*';
            txt_Password.Size = new Size(209, 23);
            txt_Password.TabIndex = 4;
            // 
            // btn_Login
            // 
            btn_Login.FlatStyle = FlatStyle.System;
            btn_Login.Font = new Font("Segoe UI", 10F);
            btn_Login.Location = new Point(52, 156);
            btn_Login.Name = "btn_Login";
            btn_Login.Size = new Size(98, 28);
            btn_Login.TabIndex = 5;
            btn_Login.Text = "Login";
            btn_Login.UseVisualStyleBackColor = true;
            btn_Login.Click += btn_Login_Click;
            // 
            // btn_Reset
            // 
            btn_Reset.Font = new Font("Segoe UI", 10F);
            btn_Reset.Location = new Point(209, 156);
            btn_Reset.Name = "btn_Reset";
            btn_Reset.Size = new Size(98, 28);
            btn_Reset.TabIndex = 6;
            btn_Reset.Text = "Reset";
            btn_Reset.UseVisualStyleBackColor = true;
            btn_Reset.Click += btn_Reset_Click;
            // 
            // btn_Exit
            // 
            btn_Exit.Font = new Font("Segoe UI", 10F);
            btn_Exit.Location = new Point(363, 156);
            btn_Exit.Name = "btn_Exit";
            btn_Exit.Size = new Size(98, 28);
            btn_Exit.TabIndex = 7;
            btn_Exit.Text = "Exit";
            btn_Exit.UseVisualStyleBackColor = true;
            btn_Exit.Click += btn_Exit_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gray;
            ClientSize = new Size(800, 450);
            Controls.Add(btn_Exit);
            Controls.Add(btn_Reset);
            Controls.Add(btn_Login);
            Controls.Add(txt_Password);
            Controls.Add(txt_Username);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "User Login Form";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txt_Username;
        private TextBox txt_Password;
        private Button btn_Login;
        private Button btn_Reset;
        private Button btn_Exit;
    }
}
