using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics.Eventing.Reader;

namespace Loginform1
{
    public partial class Form1 : Form

    {
        Double count = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.AcceptButton =btn_Login;
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void btn_Reset_Click(object sender, EventArgs e)
        {
            txt_Username.Clear();
            txt_Password.Clear();
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
           

           
                if (string.Compare(txt_Username.Text, "Mujeeb_Ul_Hassan") == 0 && string.Compare(txt_Password.Text, "22011556-016") == 0)
                {
                    MessageBox.Show("login successfully");
                   
                }
                else
                {

                count = count + 1;
                double maxcount = 3;
                double remain;
                remain = maxcount - count;
                MessageBox.Show("Wrong user name or password" + "\t" + remain + "" + " tries left");
                txt_Password.Clear();
                txt_Username.Clear();
                txt_Username.Focus();
                if(count == maxcount)
                {
                    MessageBox.Show("Max try Excedeed");
                    Application.Exit();
                        
                }
            }
            }

            
        }
    }
